
const questions = [
    {
      type: "picture-choice",
      question: "Kas ir attēlā redzamā persona?",
      imgSrc: "Pictures/KVIESIS.jfif",
      options: [
        "Gustavs Zemgals",
        "Kārlis Ulmanis",
        "Alberts Kviesis",
        "Jānis Čakste",
      ],
      answer: "Alberts Kviesis",
    },
    {
      type: "drag-and-drop",
      question: "Sakārto notikumus hronoloģiskā secībā:",
      items: [
        "Latvijas neatkarības pasludināšana",
        "Latvijas pievienošana PSRS",
        "Latvijas iestāšanās ES",
        "Atmodas kustība",
      ],
      answer: [
        "Latvijas neatkarības pasludināšana",
        "Latvijas pievienošana PSRS",
        "Atmodas kustība",
        "Latvijas iestāšanās ES",
      ],
    },
    {
      type: "text",
      question: "Kurā gadā Latvija pasludināja neatkarību?",
      answer: "1918",
    },
    {
      type: "single-choice",
      question: "Kurā gadā notika Latvijas pievienošana PSRS?",
      options: ["1940", "1941", "1944", "1945"],
      answer: "1940",
    },
    {
      type: "multiple-choice",
      question: "Izvēlies Latvijas prezidentus:",
      options: [
        "Gustavs Zemgals",
        "Kārlis Ulmanis",
        "Vladimir Putin",
        "Alfreds Rubiks",
      ],
      answer: ["Gustavs Zemgals", "Kārlis Ulmanis"],
    },
  
    {
      type: "text",
      question: "Kurš bija pirmais Latvijas prezidents?",
      answer: "Jānis Čakste",
    },
    {
      type: "single-choice",
      question: "Kurā gadā Latvija kļuva par Eiropas Savienības dalībvalsti?",
      options: ["2000", "2004", "2008", "2012"],
      answer: "2004",
    },
    {
      type: "multiple-choice",
      question: "Izvēlies Latvijas neatkarības pasludināšanas datumu:",
      options: ["18. novembris", "4. maijs", "1. janvāris", "15. oktobris"],
      answer: ["18. novembris"],
    },
    {
      type: "single-choice",
      question: "Kurš bija Latvijas pirmais ministru prezidents?",
      options: [
        "Kārlis Ulmanis",
        "Māris Gailis",
        "Andris Šķēle",
        "Valdis Dombrovskis",
      ],
      answer: "Kārlis Ulmanis",
    },
    {
      type: "multiple-choice",
      question: "Izvēlies Latvijas novadus:",
      options: ["Vidzeme", "Kurzeme", "Latgale", "Sāmsala"],
      answer: ["Vidzeme", "Kurzeme", "Latgale"],
    },
    {
      type: "drag-and-drop",
      question: "Sakārto šos Latvijas prezidentus pēc amatā stāšanās laika:",
      items: [
        "Jānis Čakste",
        "Gustavs Zemgals",
        "Kārlis Ulmanis",
        "Vaira Vīķe-Freiberga",
      ],
      answer: [
        "Jānis Čakste",
        "Gustavs Zemgals",
        "Kārlis Ulmanis",
        "Vaira Vīķe-Freiberga",
      ],
    },
    {
      type: "text",
      question: "Kurš bija pēdējais PSRS prezidents, kurš apmeklēja Latviju?",
      answer: "Mihails Gorbačovs",
    },
    {
      type: "single-choice",
      question: "Kurš gads nozīmē Latvijas pievienošanos NATO?",
      options: ["2000", "2004", "2008", "2012"],
      answer: "2004",
    },
    {
      type: "multiple-choice",
      question: "Izvēlies Latvijas galvaspilsētas nosaukumu:",
      options: ["Rīga", "Tallina", "Viļņa", "Helsinki"],
      answer: ["Rīga"],
    },
    {
      type: "text",
      question: "Kurā gadā tika atjaunota Latvijas neatkarība?",
      answer: "1991",
    },
  ];