let currentQuestionIndex = 0;
let answers = [];
let timeLeft = 600;
let countdown;
let test = [];
let showAllCorrect = false;
let showAnswer = false;

function startTest() {
  //What's the point of this if it shows only for first question
  console.log(answers); 
    const wrapper = document.getElementById("wrapper");
    wrapper.style.display = "block";
    wrapper.style.background = "white";
    document.getElementById('start-page').style.display = 'none';
    document.getElementById('question-page').style.display = 'block';
    document.getElementById("previousQuestionButton").style.display ="block";
    document.getElementById("nextQuestionButton").style.display = "block";
    document.getElementById("restartTestButton2").style.display = "none";
    
    showQuestion();
    startTimer();
    renderNumberNav();
}

function showQuestion() {
  document.getElementById("question-page").style.display = "block";
  document.getElementById("result-page").style.display = "none";

  // Update question number
   document.getElementById("question-number").innerText = `${currentQuestionIndex + 1}. jautājums`;

  // Enable or disable button "Iepriekšējais jautājums"
  let previousQuestionButton = document.getElementById("previousQuestionButton");
  if (currentQuestionIndex != 0) {
    previousQuestionButton.style.display = 'block';
  } else {
    previousQuestionButton.style.display = 'none';
  }
  
  //Create currentQuestion object, that'll hold in itself all details about one specific question (type, amswer, ect.)
  const currentQuestion = questions[currentQuestionIndex];
  console.log(currentQuestion); //Check in console how object looks like

  document.getElementById("question-title").innerText = currentQuestion.question;
   
  if (currentQuestion.type === "text") {
    document.getElementById("question-content").innerHTML =
      '<input type="text" id="answer">';
      
  } else if (currentQuestion.type === "single-choice") {
    document.getElementById("question-content").innerHTML = currentQuestion.options
      .map(
        (option) =>
          `<label><input type="radio" name="answer" value="${option}">${option}</label>`
      )
      .join("");
  } else if (currentQuestion.type === "multiple-choice") {
    document.getElementById("question-content").innerHTML = currentQuestion.options
      .map(
        (option) =>
          `<label><input type="checkbox" name="answer" value="${option}">${option}</label>`
      )
      .join("");
  } else if (currentQuestion.type === "drag-and-drop") {
    document.getElementById("question-content").innerHTML = `
            <div class="container">
                ${currentQuestion.items
                  .map(
                    (item) =>
                      `<div id="${item}" class="draggable" draggable="true">${item}</div>`
                  )
                  .join("")}
            </div>
        `;

  addDragAndDropListeners();
  
} else if (currentQuestion.type === "picture-choice") {
  document.getElementById("question-content").innerHTML = `
    <div class="picture-choice-container">
      <img src="${currentQuestion.imgSrc}" alt="Question Image" class="question-image">
      <select id="answer" class="picture-choice-dropdown">
        ${currentQuestion.options
          .map((option) => `<option value="${option}">${option}</option>`)
          .join("")}
      </select>
    </div>
  `;
}

  saveUserAnswers(currentQuestionIndex, test, currentQuestion);
  showCorrectAndUserAnswers();
  updateProgressBar();
}


function showCorrectAndUserAnswers() {
  if (showAllCorrect) {
    // Retrieve the user answer from array for the current question
    let userAnswer = test[currentQuestionIndex];
    
    // If there is no answer (undefined), set it to an empty string
    if (userAnswer == undefined) {
      userAnswer = "";
    }

    // Add HTML elements to show the correct answer and the user's answer
    document.getElementById("question-content").innerHTML += `
      <div class="question-content-correct">
        <h3>Pareizā atbilde:</h3>
        ${questions[currentQuestionIndex].answer}
      </div>
      <div class="question-content-answer">
        <h3>Tava atbilde:</h3>
        ${userAnswer}
      </div>`;

      console.log(currentQuestionIndex); // Log the current question index
      console.log(answers); // Log the answers array
  
      // Check if the user's answer is correct and change the background color accordingly
      if (answers[currentQuestionIndex]) {
        document.getElementById("wrapper").style.backgroundColor = "rgb(192, 233, 151)"; // Light green for correct
      } else {
        document.getElementById("wrapper").style.backgroundColor = "rgb(238, 121, 121)"; // Light red for incorrect
      }

    // Hide the previous and next question buttons
    document.getElementById("previousQuestionButton").style.display = "none";
    document.getElementById("nextQuestionButton").style.display = "none";
  }
}



/**
 * Saves user input in test array
 * @param {number} currentQuestionIndex - The index of the current question in the test array.
 * @param {Array} test - The array containing the user's answers for all test.
 * @param {Object} currentQuestion - The question object containing details about the current question.
 */
function saveUserAnswers(currentQuestionIndex, test, currentQuestion) {
  console.log("User answer for question", currentQuestionIndex + 1, ":", test[currentQuestionIndex]);

  if (test[currentQuestionIndex] != undefined) {
    // console.log("User answer found for question", currentQuestionIndex + 1);

    if (currentQuestion.type == "text") {
      document.getElementById("answer").value = test[currentQuestionIndex];

    } else if (currentQuestion.type == "single-choice") {
      let ans = document.querySelectorAll('input[name="answer"]');
      for (var i = 0; i < ans.length; i++) {
        if (ans[i].value == test[currentQuestionIndex]) {
          ans[i].checked = true;
          break;
        }
      }

    } else if (currentQuestion.type == "multiple-choice") {
      let ans = document.querySelectorAll('input[name="answer"]');
      for (var i = 0; i < ans.length; i++) {
        if (test[currentQuestionIndex].includes(ans[i].value)) {
          ans[i].checked = true;
        }
      }

    } else if (currentQuestion.type == "drag-and-drop") {
      document.getElementById("question-content").innerHTML = `
        <div class="container">
          ${test[currentQuestionIndex]
            .map(
              (item) =>
                `<div id="${item}" class="draggable" draggable="true">${item}</div>`
            )
            .join("")}
        </div>`;
      addDragAndDropListeners();

    } else if (currentQuestion.type == "picture-choice") {
      document.getElementById("answer").value = test[currentQuestionIndex];
    }
  }
  //Check how that array of user answers look like
  console.log(test);
}


function addDragAndDropListeners() {
  const draggables = document.querySelectorAll(".draggable");
  const container = document.querySelector(".container");

  draggables.forEach((draggable) => {
    draggable.addEventListener("dragstart", dragStart);
    draggable.addEventListener("dragend", dragEnd);
  });

  container.addEventListener("dragover", dragOver);
  container.addEventListener("drop", drop);
}

function dragStart(e) {
  e.dataTransfer.setData("text/plain", e.target.id);
  e.dataTransfer.dropEffect = "move";
  e.target.classList.add("dragging"); 

}

function dragEnd(e) {
  e.target.classList.remove("dragging");
}

function dragOver(e) {
  e.preventDefault();
  e.dataTransfer.dropEffect = "move"; 
}

function drop(e) {
  e.preventDefault();
  const id = e.dataTransfer.getData("text");
  const draggable = document.getElementById(id);
  const dropTarget = e.target;
  if (dropTarget.classList.contains("draggable")) {
    const container = dropTarget.parentNode;
    const children = Array.from(container.children);
    const indexDraggable = children.indexOf(draggable);
    const indexDropTarget = children.indexOf(dropTarget);
    if (indexDraggable !== indexDropTarget) {
      draggable.remove();
      if (indexDropTarget > indexDraggable) {
        container.insertBefore(draggable, dropTarget.nextSibling);
      } else {
        container.insertBefore(draggable, dropTarget);
      }
    }
  }
}


function saveQuestion(event) {
  // This one is always empty string, what's the point of it?
  console.log(event.target.id);
  const question = questions[currentQuestionIndex];
  let userAnswer;
  if (question.type === "text") {
    userAnswer = document.getElementById("answer").value;
  } else if (question.type === "single-choice") {
    const selectedOption = document.querySelector(
      'input[name="answer"]:checked'
    );
    userAnswer = selectedOption ? selectedOption.value : null;
  } else if (question.type === "multiple-choice") {
    userAnswer = Array.from(
      document.querySelectorAll('input[name="answer"]:checked')
    ).map((el) => el.value);
  } else if (question.type === "drag-and-drop") {
    userAnswer = Array.from(
      document.querySelectorAll(".container .draggable")
    ).map((el) => el.id);
  } else if (question.type === "picture-choice") {
    userAnswer = document.getElementById("answer").value;
  }

  // Initialize a variable to track whether the user's answer is correct
  let isCorrect = false;

  if (Array.isArray(question.answer)) {
    // If the answer is an array, compare using JSON.stringify to check equality
    if (JSON.stringify(userAnswer) === JSON.stringify(question.answer)) {
      isCorrect = true;
    }
  } else {
    // If the answer is a single value, compare directly
    if (userAnswer === question.answer) {
      isCorrect = true;
    }
  }

  // Update the test and answers arrays based on the user's answer and correctness
if (test.length == currentQuestionIndex) {
  // If the user is answering a new question, push the user's answer and its correctness to the test and answers arrays
  test.push(userAnswer);
  answers.push(isCorrect);
  // I don't get the point of this, but ok
  showAnswer = true;
} else {
  // If the user is revisiting a previously answered question, update the user's answer and its correctness at the current question index in the arrays
  test[currentQuestionIndex] = userAnswer;
  answers[currentQuestionIndex] = isCorrect;
}


  // Update the current question index based on the button clicked
  if (event.target.id == "nextQuestionButton") {
    currentQuestionIndex++;
    console.log("+"); // I don't think I need them 
  } else if (event.target.id == "previousQuestionButton") {
    currentQuestionIndex--;
    console.log("-");
  } else {
    // If a specific question button is clicked, update the current question index accordingly
    console.log("Current question index: ", event.target.getAttribute("data-number") - 1);
    currentQuestionIndex = event.target.getAttribute("data-number") - 1;
  }

  // If it's last question, change button text to "Pabeigt testu"
  const nextQuestionButton = document.getElementById("nextQuestionButton");
  if (currentQuestionIndex === questions.length - 1) {
    nextQuestionButton.innerText = "Pabeigt testu";
  } else {
    nextQuestionButton.innerText = "Nākošais jautājums";
  }

  // Display the next question 
  if (currentQuestionIndex < questions.length) {
    showQuestion();
  } else {
    // If all questions have been answered, display the results
    showAllCorrect = true;
    document.getElementById("restartTestButton2").style.display = "block";
    clearInterval(countdown);
    // Tf is this
    console.log("tikai-vienu-reizi");
    renderNumberNav();
    showResults();
  }
  updateActiveButton();
  updateProgressBar();
}


function startTimer() {
    clearInterval(countdown); 
    timeLeft = 600; 

    countdown = setInterval(() => {
        let minutes = Math.floor(timeLeft / 60);
        let seconds = timeLeft % 60;

        document.getElementById('timer').textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

        if (timeLeft <= 0) {
            clearInterval(countdown);
            showTimeoutModal();
        } else {
            timeLeft--;
        }
    }, 1000);
}


function showTimeoutModal() {
    Swal.fire({
        title: 'Laiks beidzies!',
        text: 'Noklikšķiniet uz OK pogas, lai redzētu testa rezultātus.',
        icon: 'warning',
        confirmButtonText: 'OK',
        allowOutsideClick: false
    }).then((result) => {
        if (result.isConfirmed) {
            showResults();
        }
    });
}


function showResults() {
    document.getElementById('question-page').style.display = 'none';
    document.getElementById("result-page").style.display = "block";

    //TODO: fix time display, so it shows how much time it took to finish the test
        const timer = document.getElementById("timer");
        const time = document.getElementById("result-time");
        time.innerHTML += "Tests tika pabeigts: " + timer.textContent;

    let corAnsw = 0;
    const resultIndicator = document.getElementById('result-indicator');
    resultIndicator.innerHTML = '';
    for (let i = 0; i < questions.length; i++) {
        const box = document.createElement('div');
        if (answers[i]){
          ++corAnsw;
          box.className = "result-box " + "correct";
        }else{
          box.className = "result-box " + "incorrect";
        }
        // Add question number
        box.innerText = `${i + 1}`;
        resultIndicator.appendChild(box);
    }

    document.getElementById(
      "result-content"
    ).innerText = `Pareizās atbildes: ${corAnsw} no ${questions.length}`;
}


function restartTest() {
  // Reset the text of button
    document.getElementById('nextQuestionButton').innerText = 'Nākošais jautājums';
    document.getElementById("wrapper").style.display = "none";
    clearInterval(countdown); 
    currentQuestionIndex = 0;
    correctAnswers = 0;
    test = [];
    answers=[];
    document.getElementById('result-page').style.display = 'none';
    document.getElementById('start-page').style.display = 'block';
    document.getElementById("number-navbar").innerHTML = ''; 
    document.getElementById('result-time').innerText = '';
    showAllCorrect = false;
    test.length = 0;
    // Clear the flaggedQuestions object
  for (const questionNumber in flaggedQuestions) {
    const flagImage = flaggedQuestions[questionNumber];
    flagImage.remove();
  }
  // Remove all flag images from the flag container
  flaggedQuestions = {};
}


function renderNumberNav() {
  const navbar = document.getElementById("number-navbar");
  document.getElementById("number-navbar").innerHTML = "";
  for (let i = 1; i <= questions.length ; i++) {
    const button = document.createElement("button");
    button.textContent = i;
    button.setAttribute("data-number", i);
    button.classList.add("number-button");
    button.onclick = function (event) {
      if(showAllCorrect == false){
        saveQuestion(event);
      }
      else{
        currentQuestionIndex = i-1;
        showQuestion();
      }
    };
    navbar.appendChild(button);
  }
  updateActiveButton();
}


function updateActiveButton() {
  const buttons = document.querySelectorAll(".number-button");
  buttons.forEach((button, index) => {
    if (index === currentQuestionIndex) {
      button.classList.add("active");
    } else {
      button.classList.remove("active");
    }
  });
}


document.getElementById("toggle-dark-mode").addEventListener("click", function() {
  // Toggle dark mode class on body
  document.documentElement.classList.toggle("dark-mode");
});


document.addEventListener('keydown', function(event) {
  if (event.ctrlKey && event.code === 'KeyC' && !isStartScreenVisible()) {
      event.preventDefault();
      showAnswerPopup();
  }
});

function isStartScreenVisible() {
  return document.getElementById('start-page').offsetParent !== null;
}

function showAnswerPopup() {
  const currentQuestion = questions[currentQuestionIndex];
  let correctAnswer = currentQuestion.answer;
  
  Swal.fire({
      title: 'Oh no!<br>Looks like someone lacks intelligence.',
      text: `Correct answer: ${Array.isArray(correctAnswer) ? correctAnswer.join(", ") : correctAnswer}`,
      icon: 'info',
      confirmButtonText: 'OK'
  });
}

//Show this bar in result page also or just add text how much q u finished?
function updateProgressBar() {
  const progressBar = document.getElementById('progress-bar');
  const progressText = document.getElementById('progress-text');

  // Filter out null, undefined, empty array, and empty string answers from the test array
  const answeredQuestions = test.filter(answer => {
    return answer !== null && answer !== undefined && !(Array.isArray(answer) && answer.length === 0) && answer !== '';
  }).length;

  const totalQuestions = questions.length;
  const progress = (answeredQuestions / totalQuestions) * 100;

  progressBar.style.width = `${progress}%`;
  progressText.innerText = `${answeredQuestions}/${totalQuestions}`;
}


// Define variables to store the current active button and flag image
let activeButton = null;
let activeFlag = null;

// Store the association between buttons and flagged questions
const flaggedQuestions = {};

function placeFlag() {
  const navbarButton = document.querySelector('.number-button.active');
  const flagContainer = document.getElementById('flagContainer');

  if (navbarButton) {
    // Get the question number associated with the button
    const questionNumber = navbarButton.getAttribute('data-number');

    // Check if the question is already flagged
    if (flaggedQuestions[questionNumber]) {
      // Remove the flag image if it exists for the same question
      const flagImage = flaggedQuestions[questionNumber];
      flagImage.remove();
      // Remove the association between the button and the flagged question
      delete flaggedQuestions[questionNumber];
    } else {
      // Create a new flag image element
      const flagImage = document.createElement('img');
      flagImage.src = 'Pictures/flag.png';
      flagImage.alt = 'Flag';
      flagImage.classList.add('flag-image'); 

      const flagWidth = 20; 
      const flagHeight = 20; 
      flagImage.style.width = `${flagWidth}px`;
      flagImage.style.height = `${flagHeight}px`;

      // Position the flag image on top of the navbar button
      const navbarButtonRect = navbarButton.getBoundingClientRect();
      const flagTop = navbarButtonRect.top - flagHeight; // Position the flag above the button
      const flagLeft = navbarButtonRect.left + ((navbarButtonRect.width - flagWidth) / 2); // Center the flag horizontally
      flagImage.style.position = 'fixed';
      flagImage.style.top = `${flagTop}px`;
      flagImage.style.left = `${flagLeft}px`;

      // Append the flag image to the flag container
      flagContainer.appendChild(flagImage);

      // Store the association between the button and the flagged question
      flaggedQuestions[questionNumber] = flagImage;
    }
  }
}

const lightBulb = document.getElementById('lightImage');
lightBulb.addEventListener('click', function() {
    lightBulb.classList.add('swing-animation');

    // Remove the class after the animation ends to enable subsequent clicks
    setTimeout(function() {
        lightBulb.classList.remove('swing-animation');
    }, 500); 
});
